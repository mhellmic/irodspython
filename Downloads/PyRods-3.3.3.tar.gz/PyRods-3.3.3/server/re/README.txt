DIRECTORY
	iRODS/server/re		- Rule engine functions

DESCRIPTION
	This directory contains rule engine support for the
	iRODS server.
