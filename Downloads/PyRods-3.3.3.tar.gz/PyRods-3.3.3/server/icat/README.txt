DIRECTORY
	iRODS/server/icat	- ICAT functions

DESCRIPTION
	This directory contains functions for the ICAT metadata
	catalog which manages persistent-state information for
        the IRODS system: system and user-defined metadata on
        data objects, collections, resources, users, etc.
