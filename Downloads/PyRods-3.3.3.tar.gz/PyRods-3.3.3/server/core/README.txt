DIRECTORY
	iRODS/server/core	- core server functions

DESCRIPTION
	This directory contains core utility functions and server
	main programs used by the servers and microservices.
