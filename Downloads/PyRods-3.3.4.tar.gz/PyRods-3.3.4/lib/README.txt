DIRECTORY
	iRODS/lib	- iRODS utility library

DESCRIPTION
	This directory, and its subdirectories, contains functions for
	the iRODS utility library.  The library includes client API
	functions and core functions needed throughout iRODS.
